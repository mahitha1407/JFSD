package net.javaguides.springboot.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "book")
public class Book {
	
	@Id
	private String Name;
	private String Email;
	private String PhoneNumber;
	private String DateOfTravel;
	private String Source;
	private String Chooseyourflight;
	private String EstimatedCost;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phone_number) {
		PhoneNumber = phone_number;
	}
	public String getDateOfTravel() {
		return DateOfTravel;
	}
	public void setDateOfTravel(String date_of_travel) {
		DateOfTravel = date_of_travel;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getChooseyourflight() {
		return Chooseyourflight;
	}
	public void setChooseyourflight(String chooseyourflight) {
		Chooseyourflight = chooseyourflight;
	}
	public String getEstimatedCost() {
		return EstimatedCost;
	}
	public void setEstimatedCost(String estimated_Cost) {
		EstimatedCost = estimated_Cost;
	}
	
	
}	