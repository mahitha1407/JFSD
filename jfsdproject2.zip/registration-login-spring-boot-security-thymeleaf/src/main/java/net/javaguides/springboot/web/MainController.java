package net.javaguides.springboot.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import net.javaguides.springboot.DAO;
import net.javaguides.springboot.model.Book;

@Controller
public class MainController {
	

	@Autowired
	DAO dao;

	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping("/")
	public String home() {
		return "index";
	}
	
	@GetMapping("/contact")
	public String contact() {
		return "contact";
	}
	@GetMapping("/about")
	public String about() {
		return "about";
	}
	@GetMapping("/index")
	public String index() {
		return "index";
	}
	
	@GetMapping("/bookings")
	public String bookings() {
		return "bookings";
	}
	@GetMapping("/reverification")
	public String reverification() {
		return "reverification";
	}
	@GetMapping("/payment")
	public String payment() {
		return "payment";
	}
	
	@GetMapping("/booking")
	public String booking() {
		return "booking";
	}
	@GetMapping("/card")
	public String card() {
		return "card";
	}
	@GetMapping("/book")
	public String book () {
		return "book";
	}
	@GetMapping("/can")
	public String can() {
		return "can";
	}
	@GetMapping("/paris")
	public String paris() {
		return "paris";
	}
	@GetMapping("/london")
	public String london() {
		return "london";
	}
	@GetMapping("/miami")
	public String miami() {
		return "miami";
	}
	@GetMapping("/disneyland")
	public String disneyland() {
		return "disneyland";
	}
	@GetMapping("/hawai")
	public String hawai() {
		return "hawai";
	}
	@GetMapping("/vietnam")
	public String vietnam() {
		return "vietnam";
	}
	@GetMapping("/manali")
	public String manali() {
		return "manali";
	}
	@GetMapping("/goa")
	public String goa() {
		return "goa";
	}
	
	@GetMapping("/indexes")
	public String indexes() {
	return "indexes";
	 }


			
			@ResponseBody
			@GetMapping("/book1")
			public String fun2(javax.servlet.http.HttpServletRequest request)
			{
				System.out.println("welcome");
				Book b1=new Book();
				b1.setName(request.getParameter("name"));
				b1.setEmail(request.getParameter("email"));
				b1.setPhoneNumber(request.getParameter("phoneNumber"));
				b1.setDateOfTravel(request.getParameter("dateOfTravel"));
				b1.setSource(request.getParameter("source"));
				b1.setChooseyourflight(request.getParameter("chooseyourflight"));
				b1.setEstimatedCost(request.getParameter("estimatedcost"));
				
				System.out.println(b1);
			
				dao.insert(b1);
				
						
				return "saved successfully";
			}
}
