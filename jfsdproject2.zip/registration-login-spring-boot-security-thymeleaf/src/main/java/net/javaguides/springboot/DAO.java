package net.javaguides.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.javaguides.springboot.model.Book;
import net.javaguides.springboot.repository.BookRepository;

@Service
public class DAO {

	
	@Autowired
	BookRepository repo;
	
	public void insert(Book b1)
	{
		repo.save(b1);
	}

}
